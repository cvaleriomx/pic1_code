# RFQ TRANSOPTR Designer

This folder contains a v1 iterative RFQ designer.  It generates `table1.txt`,
`fort.75`, `sy.f`, `history.csv`, iteration folders, and basic plots.

Quick start with the mock runner:

```bash
python -m rfq_transop_design.design_rfq rfq_transop_design/example_design.yaml
```

To use real TRANSOPTR, set:

```yaml
transoptr:
  runner: optr
  command: /path/to/optr
  template_data: /path/to/data.dat
```

The design reference requested for this tool is `rfq_book.pdf`, pages 23-32.
The current implementation keeps the same RFQ conventions already used in this
repo for `fort.75`: `s_cm A01 A10 k_cm_inv`.

