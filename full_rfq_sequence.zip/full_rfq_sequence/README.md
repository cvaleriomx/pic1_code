# Full RFQ Sequence

Carpeta autocontenida para correr el hilo actual:

1. Leer `fort.75` como tabla de coeficientes `s_cm A01 A10 k_cm_inv`.
2. Generar `campo_corregido_ISAC2.pkl` con `create_warp_field.py`.
3. Copiar el campo a `warp_sim/`.
4. Correr tracking con `warp_sim/rfq_generatedfield.py`.

Uso normal:

```bash
cd full_rfq_sequence
./run_full_sequence.sh 1.0
```

El argumento `1.0` es el factor de voltaje que usa Warp. En el script actual:

```python
v0 = 35.2e3 * factor
```

Para solo regenerar el campo, sin correr Warp:

```bash
cd full_rfq_sequence
SKIP_WARP=1 ./run_full_sequence.sh
```

Si quieres regenerar `fort.75` desde la herramienta de referencia:

```bash
cd full_rfq_sequence
REGENERATE_FORT75=1 SKIP_WARP=1 ./run_full_sequence.sh
```

Nota: el `fort.75` local es una copia del último archivo equivalente usado por el hilo actual, `RM2/olivier_1/fort.76`.
