#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PYTHON_BIN="${PYTHON_BIN:-python}"
VOLTAGE_FACTOR="${1:-1.0}"
REGENERATE_FORT75="${REGENERATE_FORT75:-0}"
SKIP_WARP="${SKIP_WARP:-0}"

echo "== Full RFQ sequence =="
echo "Carpeta: $SCRIPT_DIR"
echo "Python: $PYTHON_BIN"
echo "Factor de voltaje Warp: $VOLTAGE_FACTOR"
echo

if [[ "$REGENERATE_FORT75" == "1" ]]; then
    echo "[1/4] Regenerando fort.75 desde reference_tools/table2_dans.txt"
    (
        cd reference_tools
        "$PYTHON_BIN" import_re.py
    )
    cp reference_tools/fort.75 fort.75
else
    echo "[1/4] Usando fort.75 local existente"
fi

if [[ ! -s fort.75 ]]; then
    echo "ERROR: no existe fort.75 o esta vacio en $SCRIPT_DIR" >&2
    exit 1
fi

echo "[2/4] Generando campo Warp desde fort.75"
"$PYTHON_BIN" create_warp_field.py

if [[ ! -s campo_corregido_ISAC2.pkl ]]; then
    echo "ERROR: no se genero campo_corregido_ISAC2.pkl" >&2
    exit 1
fi

echo "[3/4] Copiando campo generado a warp_sim/"
cp campo_corregido_ISAC2.pkl warp_sim/campo_corregido_ISAC2.pkl
mkdir -p warp_sim/salida

if [[ "$SKIP_WARP" == "1" ]]; then
    echo "[4/4] SKIP_WARP=1: campo listo, no corro Warp."
    exit 0
fi

echo "[4/4] Corriendo tracking en Warp"
(
    cd warp_sim
    MPLBACKEND="${MPLBACKEND:-Agg}" "$PYTHON_BIN" rfq_generatedfield.py "$VOLTAGE_FACTOR"
)

echo
echo "Secuencia terminada."
echo "Campo: $SCRIPT_DIR/campo_corregido_ISAC2.pkl"
echo "Salidas Warp: $SCRIPT_DIR/warp_sim/salida"
